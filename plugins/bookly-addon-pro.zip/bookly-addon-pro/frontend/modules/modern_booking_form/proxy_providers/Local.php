<?php
namespace BooklyPro\Frontend\Modules\ModernBookingForm\ProxyProviders;

use Bookly\Lib as BooklyLib;
use Bookly\Frontend\Modules\ModernBookingForm\Proxy;
use BooklyPro\Frontend\Modules\ModernBookingForm\Lib\PaymentFlow;

/**
 * Class Local
 *
 * @package BooklyPro\Frontend\Modules\ModernBookingForm\ProxyProviders
 */
class Local extends Proxy\Pro
{
    /**
     * @param BooklyLib\Entities\Payment $payment
     * @return void
     */
    protected static function setPaymentCompleted( $payment )
    {
        PaymentFlow::setCompleted( $payment );
    }
}