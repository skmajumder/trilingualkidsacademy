<?php
namespace BooklyPro\Lib\Entities\ProxyProviders;

use Bookly\Lib;
use Bookly\Lib\Entities\Proxy;
use BooklyPro\Lib\Entities\GiftCard;
use BooklyPro\Lib\Entities\GiftCardType;

/**
 * Class Shared
 * @package BooklyPro\Lib\Entities\ProxyProviders
 */
class Shared extends Proxy\Shared
{
    /**
     * @inerhitDoc
     */
    public static function preparePaymentDetails( array $details, Lib\Entities\Payment $payment )
    {
        if ( $payment->getTarget() === Lib\Entities\Payment::TARGET_GIFT_CARDS ) {
            foreach ( $details['items'] as &$item ) {
                $data = GiftCard::query( 'g' )
                    ->select( 'g.code, g.gift_card_type_id, gt.title' )
                    ->leftJoin( 'GiftCardType', 'gt', 'gt.id = g.gift_card_type_id' )
                    ->where( 'g.id', $item['id'] )
                    ->fetchRow();
                if ( $data ) {
                    $card_type = new GiftCardType( array( 'id' => $data['gift_card_type_id'], 'title' => $data['title'] ) );
                    $item['type'] = $card_type->getTranslatedTitle();
                    $item['code'] = $data['code'];
                }
            }
        }

        return $details;
    }
}