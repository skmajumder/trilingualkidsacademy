<?php
namespace BooklyPro\Lib\Zoom\Jwt;

class BeforeValidException extends \UnexpectedValueException
{
}
